<?php
/******************************************************************************/
/*                                                                            */
/* config.inc.php - Configuration file                                        */
/*                                                                            */
/******************************************************************************/

/*                                                                            */
/* General Configuration                                                      */
/* ---------------------                                                      */
/* PHPRPG_DEBUG : Project debug mode, enter a boolean value (True or False)   */
/* PHPRPG_BASE : Base URL to where the main files are located, with trailing  */
/*               slash '/' (e.g. 'http://www.yourwebserver.com/game_one/')    */
/* PHPRPG_IMG : Base URL to where the image files are located; again, include */
/*              the trailing slash                                            */
/* PHPRPG_MAIL : Appear as the sender's e-mail address on e-mails and notices */
/*               sent to players                                              */
/*                                                                            */

define('PHPRPG_DEBUG', False);
define('PHPRPG_BASE', 'http://thevedic.net/cf/');
define('PHPRPG_IMG', 'http://thevedic.net/cf/images/');
define('PHPRPG_MAIL', 'admin@thevedic.net');


/*                                                                            */
/* MySQL Database Configuration                                               */
/* ----------------------------                                               */
/* PHPRPG_DB_HOST : MySQL host; server name only (e.g. 'mysql.webserver.com') */
/* PHPRPG_DB_NAME : Name of MySQL database                                    */
/* PHPRPG_DB_USER : MySQL username                                            */
/* PHPRPG_DB_PASS : MySQL password                                            */
/* PHPRPG_DB_PREFIX : The prefix prepended to all table names                 */
/*                                                                            */

define('PHPRPG_DB_HOST', 'localhost');
define('PHPRPG_DB_NAME', 'vedic');
define('PHPRPG_DB_USER', 'vedic');
define('PHPRPG_DB_PASS', 'r3drum');
define('PHPRPG_DB_PREFIX', 'cf');


/*                                                                            */
/* Game Configuration                                                         */
/* ------------------                                                         */
/* PHPRPG_SESSION_EXPIRY : Seconds before automatic session termination       */
/* PHPRPG_EPOCH : UNIX TIMESTAMP that defines the start of time               */
/*                                                                            */

define('PHPRPG_SESSION_EXPIRY', '1200');
define('PHPRPG_EPOCH', '994737600');

/* Last tile_realmxx.png */
$max_tiles = "3";

/* Name of the game, for headers */
$game_name = "Aarait 2: Chicken Fight";


/* Player Start Info */
$start_map_name = 'Penny Farms';
$start_map_x = 0;
$start_map_y = 0;
$start_race = 'Chicken';
$start_avatar = 'soul';


/*                                                                            */
/* DO NOT MODIFY BEYOND THIS POINT                                            */
/* ----------------------------                                               */
/* PHP_SELF: Script name only (no path)                                       */
/*                                                                            */

ereg("([^\\/]*)$", $HTTP_SERVER_VARS['PHP_SELF'], $php_self);
define('PHP_SELF', $php_self[1]);

?>
