<?php
/******************************************************************************/
/*                                                                            */
/* template_chat.inc.php - HTML Chat Box                                      */
/*                                                                            */
/******************************************************************************/
/*                                                                            */
/* Requirements: PHP, MySQL and web-browser                                   */
/*                                                                            */
/* Author: Timothy TS Chung                                                   */
/*         <ttschung@users.sourceforge.net>                                   */
/*                                                                            */
/* Created: 15 March 2002                                                     */
/*                                                                            */
/* Copyright (c) 2001-2002 Timothy TS Chung                                   */
/*                                                                            */
/* This file is part of phpRPG (http://phpRPG.org/)                           */
/*                                                                            */
/* phpRPG is free software; you can redistribute it and/or modify             */
/* it under the terms of the GNU General Public License as published by       */
/* the Free Software Foundation; either version 2 of the License, or          */
/* (at your option) any later version.                                        */
/*                                                                            */
/* This program is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/* GNU General Public License for more details.                               */
/*                                                                            */
/* You should have received a copy of the GNU General Public License          */
/* along with this program; if not, write to the Free Software                */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/******************************************************************************/


error_reporting (E_ALL);

if (eregi('.inc.php', $HTTP_SERVER_VARS['PHP_SELF']))
{
    header('Location: index.php');
}
else
{
// Display chat input box
echo '
<form action="' . PHP_SELF . '?s=' . $s . '" method="post" name="chatbox">
<img src="' . PHPRPG_IMG . 'babble.png" width="10" height="10" border="0" alt="chat">
<input type="hidden" name="option" value="chat">
<input type="text" name="voice" maxlength="100" size="30" class="input" onFocus="javascript:textSwitch=1;">
&nbsp;[<a href="' . PHP_SELF . '?s=' . $s . '">Refresh</a>]
</form>
';

// Select the users who have said something in this sector, sorted by the last posting time
$player_list = array();
$result = mysql_query("SELECT name, MAX(post_time) AS max_time FROM " . PHPRPG_DB_PREFIX . "_chat WHERE map_name='" . $char['map_name'] . "' AND map_xpos='" . $char['map_xpos'] . "' AND map_ypos='" . $char['map_ypos'] . "' GROUP BY name ORDER BY max_time DESC") or die('Database Error: ' . mysql_error() . '<br>');
if (mysql_num_rows($result) > 0)
{
    while ($player = mysql_fetch_array($result))
    {
        // See if player is within the sector
        $result_check = mysql_query("SELECT user_id, avatar, HP FROM " . PHPRPG_DB_PREFIX . "_users WHERE name='" . $player['name'] . "' AND map_name='" . $char['map_name'] . "' AND map_xpos='" . $char['map_xpos'] . "' AND map_ypos='" . $char['map_ypos'] . "' LIMIT 1");

        if (mysql_num_rows($result_check) == 1)
        {
            // Yes, player is still within the sector, add to list of players
            $player_list[] = $player['name'];
            $player_avatar = mysql_fetch_array($result_check);

            // Display the latest chat messages of the particular player
            $result_messages = mysql_query("SELECT contents FROM " . PHPRPG_DB_PREFIX . "_chat WHERE name='" . $player['name'] . "' AND map_name='" . $char['map_name'] . "' AND map_xpos='" . $char['map_xpos'] . "' AND map_ypos='" . $char['map_ypos'] . "' ORDER BY post_time DESC LIMIT 6");

            echo '
<table cellpadding="0" cellspacing="0" border="0">
<tr>
<td></td>
<td><img src="' . PHPRPG_IMG . 'quote_ul.png" width="15" height="7" border="0" alt=""></td>
<td background="' . PHPRPG_IMG . 'quote_tp.png"><img src="' . PHPRPG_IMG . 'x.png" width="1" height="1" border="0"></td>
<td><img src="' . PHPRPG_IMG . 'quote_ur.png" width="15" height="7" border="0" alt=""></td>
</tr>
<tr>
';

            $chat_player_string = '<td><div align="center"><img src="' . PHPRPG_IMG . 'avatar_' . $player_avatar['avatar'] . '.png" width="49" height="49" border="0" alt="' . $player['name'] . '"><br><font size="1">' . $player['name'] . '<BR>(HP:' . $player_avatar['HP'] . ')</div></td>';
            if (PHP_SELF == 'battle.php' && $player_avatar['user_id'] != $user_id)
            {
                $chat_player_string = '
<td><table cellpadding="0" cellspacing="2" border="0"><tr>' . $chat_player_string . '
<td valign="top">
<a href="action.php?s=' . $s . '&option=attack&id=' . $player_avatar['user_id'] . '&ref=' . PHP_SELF . '"><img src="' . PHPRPG_IMG . 'action_attack.png" width="20" height="20" border="0" alt="Attack"></a><br>
<img src="' . PHPRPG_IMG . 'action_heal.png" width="20" height="20" border="0" alt="Heal"><br>
<img src="' . PHPRPG_IMG . 'action_use.png" width="20" height="20" border="0" alt="Use"><br></td></tr></table></td>
                ';
            }
            echo $chat_player_string;

            echo '
<td background="' . PHPRPG_IMG . 'quote_lt.png"><img src="' . PHPRPG_IMG . 'x.png" width="1" height="1" border="0"></td>
<td>
            ';

            $i = 0;
            while ($player_messages = mysql_fetch_array($result_messages))
            {
                switch ($i)
                {
                    case 0:
                        $font_color = 'eeeeee';
                        break;
                    case 1:
                        $font_color = 'c6c6c6';
                        break;
                    case 2:
                        $font_color = 'bbbbbb';
                        break;
                    case 3:
                        $font_color = '969696';
                        break;
                    case 4:
                        $font_color = '888888';
                        break;
                    case 5:
                        $font_color = '666666';
                        break;
                    case 6:
                        $font_color = '555555';
                        break;
                }
                $i++;
                echo '<font size="1" color="#' . $font_color . '">&gt; ' . $player_messages['contents'] . '</font><br>';
            }
            mysql_free_result($result_messages);

            echo '
</td>
<td background="' . PHPRPG_IMG . 'quote_rt.png"><img src="' . PHPRPG_IMG . 'x.png" width="1" height="1" border="0"></td>
</tr>
<tr>
<td></td>
<td><img src="' . PHPRPG_IMG . 'quote_dl.png" width="15" height="7" border="0" alt=""></td>
<td background="' . PHPRPG_IMG . 'quote_bt.png"><img src="' . PHPRPG_IMG . 'x.png" width="1" height="1" border="0"></td>
<td><img src="' . PHPRPG_IMG . 'quote_dr.png" width="15" height="7" border="0" alt=""></td>
</tr>
</table>
<img src="' . PHPRPG_IMG . 'x.png" width="1" height="1" vspace="5" border="0"><br>
            ';

        }

        mysql_free_result($result_check);

    }
}

// Display the rest of the players in sector, who are not talking
$result = mysql_query("SELECT user_id, name, avatar, HP FROM " . PHPRPG_DB_PREFIX . "_users WHERE user_id !=$user_id AND map_name='" . $map . "' AND map_xpos='" . $xpos . "' AND map_ypos='" . $ypos . "' ORDER BY name");
if (mysql_num_rows($result) > 0)
{
    echo '
<table cellpadding="2" cellspacing="0" border="0">
<tr>
    ';

    $i = 0;

    while ($player = mysql_fetch_array($result))
    {
        if (in_array($player['name'], $player_list) == False)
        {
            $i++;
            $player_string = '<td><div align="center"> <img src="' . PHPRPG_IMG . 'avatar_' . $player['avatar'] . '.png" width="49" height="49" border="0" alt="' . $player['name'] . '"><br><font size="1">' . $player['name'] . '<BR>(HP:' . $player['HP'] . ') </div></td>';
            if (PHP_SELF == 'battle.php' && $player['user_id'] != $user_id)
            {
                $player_string = '
<td valign="top"><table cellpadding="0" cellspacing="2" border="0"><tr>' . $player_string . '
<td valign="top">
<a href="action.php?s=' . $s . '&option=attack&id=' . $player['user_id'] . '&ref=' . PHP_SELF . '"><img src="' . PHPRPG_IMG . 'action_attack.png" width="20" height="20" border="0" alt="Attack"></a><br>
<img src="' . PHPRPG_IMG . 'action_heal.png" width="20" height="20" border="0" alt="Heal"><br>
<img src="' . PHPRPG_IMG . 'action_use.png" width="20" height="20" border="0" alt="Use"><br></td></tr></table></td>
                ';
            }
            echo $player_string;
            if($i == 9 || $i == 18) {
              echo '</tr><tr>';
            }
        }
    }
    echo '
</tr>
</table>
    ';
}

}
?>
