<?php 
require("config.inc.php"); 
require("lib.inc.php"); 

$user_name = "admin"; 
$user_pass = "l0ser"; 

$t = md5($user_pass);

DbConnect(); 
$sql = "UPDATE " . PHPRPG_DB_PREFIX . "_users SET user_pass='$t' where user_name='$user_name'"; 
mysql_query($sql) or die(mysql_error()); 

print "$t";
?> 
