<?php
/******************************************************************************/
/*                                                                            */
/* admin.php - phpRPG Administration                                          */
/*                                                                            */
/******************************************************************************/
/*                                                                            */
/* Requirements: PHP, MySQL and web-browser                                   */
/*                                                                            */
/* Author: Timothy TS Chung                                                   */
/*         <ttschung@users.sourceforge.net>                                   */
/*                                                                            */
/* Created: 13 February 2002                                                  */
/*                                                                            */
/* Copyright (c) 2001-2002 Timothy TS Chung                                   */
/*                                                                            */
/* This file is part of phpRPG (http://phpRPG.org/)                           */
/*                                                                            */
/* phpRPG is free software; you can redistribute it and/or modify             */
/* it under the terms of the GNU General Public License as published by       */
/* the Free Software Foundation; either version 2 of the License, or          */
/* (at your option) any later version.                                        */
/*                                                                            */
/* This program is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/* GNU General Public License for more details.                               */
/*                                                                            */
/* You should have received a copy of the GNU General Public License          */
/* along with this program; if not, write to the Free Software                */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/******************************************************************************/

error_reporting (E_ALL);

require('config.inc.php');

echo '
<html>
<head>
<title>Create DB tables for phpRPG</title>
</head>
<body>
';
        echo '<b>Creating tables...</b><br><br>';

        $db = mysql_pconnect(PHPRPG_DB_HOST, PHPRPG_DB_USER, PHPRPG_DB_PASS) or die(mysql_error());
        mysql_select_db(PHPRPG_DB_NAME) or die(mysql_error());

/* EXAMPLE

        $query = "
INSERT INTO " . PHPRPG_DB_PREFIX . "_items VALUES (1, 0, 1, 'Blue Aura', '', 5, 1, 'flashes', 2, '', 'blueaura', 'Penny Farms', 4, 4)
        ";

        $sql = mysql_query($query) or die(mysql_error());
        echo '.';
        $query = "
INSERT INTO " . PHPRPG_DB_PREFIX . "_items_factsheet VALUES (1, 'Blue Aura', 'aura', 100, 5, 1, 'flashes', 2, 'M,F', 'soul', 'none', '', 'blueaura')
        ";

       $sql = mysql_query($query) or die(mysql_error());
        echo '.';

*/


echo '
</body>
</html>
';

?>
