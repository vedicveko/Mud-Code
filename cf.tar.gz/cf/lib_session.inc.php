<?php
/******************************************************************************/
/*                                                                            */
/* lib_session.inc.php - Validates current session and updates the database   */
/*                                                                            */
/******************************************************************************/
/*                                                                            */
/* Requirements: PHP, MySQL and web-browser                                   */
/*                                                                            */
/* Author: Timothy TS Chung                                                   */
/*         <ttschung@users.sourceforge.net>                                   */
/*                                                                            */
/* Created: 17 March 2002                                                     */
/*                                                                            */
/* Copyright (c) 2001-2002 Timothy TS Chung                                   */
/*                                                                            */
/* This file is part of phpRPG (http://phpRPG.org/)                           */
/*                                                                            */
/* phpRPG is free software; you can redistribute it and/or modify             */
/* it under the terms of the GNU General Public License as published by       */
/* the Free Software Foundation; either version 2 of the License, or          */
/* (at your option) any later version.                                        */
/*                                                                            */
/* This program is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/* GNU General Public License for more details.                               */
/*                                                                            */
/* You should have received a copy of the GNU General Public License          */
/* along with this program; if not, write to the Free Software                */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/******************************************************************************/


error_reporting (E_ALL);

if (!empty($HTTP_SESSION_VARS['user_id']))
{
    unset($HTTP_SESSION_VARS['user_id']);
}

session_set_save_handler('SessOpen', '', 'SessRead', 'SessWrite', 'SessDestroy', 'SessGc');
session_id($s);
session_start();

if (!empty($HTTP_SESSION_VARS['user_id']))
{
    $user_id = $HTTP_SESSION_VARS['user_id'];
    $user_time_old = $HTTP_SESSION_VARS['user_time'];
    $user_time_min = time() - PHPRPG_SESSION_EXPIRY;

    // Redirect to default page if session has expired
    if ($user_time_old < $user_time_min)
    {
        session_unset();
        session_destroy();
        header('Location: index.php');
        exit;
    }

    // Continue with session
    $user_time = time();
    DbConnect();
    // Update last_active
    $result = mysql_query("UPDATE " . PHPRPG_DB_PREFIX . "_users SET last_active='$user_time' WHERE user_id=$user_id LIMIT 1");
    // Refresh stats
    $result = mysql_query("SELECT name, user_pass, HP, HP_MAX, MP, MP_MAX, STM, STM_MAX, EXP, GP, map_name, map_xpos, map_ypos, delay, delay_reason, race, avatar FROM " . PHPRPG_DB_PREFIX . "_users WHERE user_id=$user_id LIMIT 1");
    $char = mysql_fetch_array($result);
    // Check admin level
    $result = mysql_query("SELECT level FROM " . PHPRPG_DB_PREFIX . "_admins WHERE user_id=" . $user_id . " LIMIT 1");
    list($char['admin_level']) = mysql_fetch_row($result);
}
else
{
    // Redirect to default page if session variables do not exist
    header('Location: index.php');
    exit;
}
?>
