<?php
/******************************************************************************/
/*                                                                            */
/* lib_events.inc.php - Event Handler and Processor - the Cron, Load Balancer */
/*                                                                            */
/******************************************************************************/
/*                                                                            */
/* Requirements: PHP, MySQL and web-browser                                   */
/*                                                                            */
/* Author: Timothy TS Chung                                                   */
/*         <ttschung@users.sourceforge.net>                                   */
/*                                                                            */
/* Created: 2 April 2002                                                      */
/*                                                                            */
/* Copyright (c) 2001-2002 Timothy TS Chung                                   */
/*                                                                            */
/* This file is part of phpRPG (http://phpRPG.org/)                           */
/*                                                                            */
/* phpRPG is free software; you can redistribute it and/or modify             */
/* it under the terms of the GNU General Public License as published by       */
/* the Free Software Foundation; either version 2 of the License, or          */
/* (at your option) any later version.                                        */
/*                                                                            */
/* This program is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              */
/* GNU General Public License for more details.                               */
/*                                                                            */
/* You should have received a copy of the GNU General Public License          */
/* along with this program; if not, write to the Free Software                */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/******************************************************************************/


error_reporting (E_ALL);

if (eregi('.inc.php', $HTTP_SERVER_VARS['PHP_SELF']))
{
    header('Location: index.php');
}
else
{

// sort be priority, time - optimise tables... chat > sessions > pending
// also NPC handling and constructions

$result_events = mysql_query("SELECT task, requested, due FROM " . PHPRPG_DB_PREFIX . "_events WHERE (assigned_id = '0' AND due < " . time() . ") ORDER BY priority, requested LIMIT 2 FOR UPDATE");

$events_string = '';

while ($event = mysql_fetch_array($result_events))
{

switch ($event['task'])
{
    case 'clear_chat':
        // Move chat messages longer than a specified time frame 5 mins (300s) to chat_log every minute
        $online_range = time() - 300;
        $result_insert = mysql_query("INSERT " . PHPRPG_DB_PREFIX . "_chat_log (avatar, emotion, name, map_name, map_xpos, map_ypos, contents, post_time) SELECT avatar, emotion, name, map_name, map_xpos, map_ypos, contents, post_time FROM " . PHPRPG_DB_PREFIX . "_chat WHERE (post_time < $online_range AND type = 'chat')");
        $result_delete = mysql_query("DELETE FROM " . PHPRPG_DB_PREFIX . "_chat WHERE post_time < $online_range");
        $next_update = time() + 60;
        $result_update = mysql_query("UPDATE " . PHPRPG_DB_PREFIX . "_events SET requested = '" . time() . "', due = '" . $next_update . "' WHERE task = '" . $event['task'] . "' LIMIT 1");
        $events_string .= ' clear_chat';
        break;

    case 'optimize_chat':
        // Optimize chat table 20 minutes
        $result = mysql_query("OPTIMIZE TABLE " . PHPRPG_DB_PREFIX . "_chat");
        $next_update = time() + (60 * 20);
        $result_update = mysql_query("UPDATE " . PHPRPG_DB_PREFIX . "_events SET requested = '" . time() . "', due = '" . $next_update . "' WHERE task = '" . $event['task'] . "' LIMIT 1");
        $events_string .= ' optimize_chat';
        break;

    case 'clear_users_pending':
        // Clean up! -> Purge pending accounts registered greater than 48 hours (172800s) every hour
        $online_range = time() - 172800;
        $result_delete = mysql_query("DELETE FROM " . PHPRPG_DB_PREFIX . "_users_pending WHERE rego_time < $online_range");
        $next_update = time() + (60 * 60);
        $result_update = mysql_query("UPDATE " . PHPRPG_DB_PREFIX . "_events SET requested = '" . time() . "', due = '" . $next_update . "' WHERE task = '" . $event['task'] . "' LIMIT 1");
        $events_string .= ' clear_users_pending';
        break;

    case 'stamina_recovery':
        // Stamina recovery every 5 minutes
        // -> amount of recovery depends on fatigue (ie current STM status) and VIT

        // Bonus stamina recovery if player is camping...?

        // Check how many cycles this event might have been missed - Not a true algorithm, but better than nothing :)
        $event_cycles = round((time() - $event['due']) / (60 * 5)) + 1;

        //    STM   >60% -> 4 per 5 mins = 48 per hour
        $result_stamina_up = mysql_query("UPDATE " . PHPRPG_DB_PREFIX . "_users SET STM = CEILING(STM + 4 * VIT / 8) * $event_cycles WHERE (STM/STM_MAX) > 0.6 AND STM != STM_MAX");

        //    STM 30-60% -> 3 per 5 mins = 36 per hour
        $result_stamina_up = mysql_query("UPDATE " . PHPRPG_DB_PREFIX . "_users SET STM = CEILING(STM + 3 * VIT / 8) * $event_cycles WHERE (STM/STM_MAX) > 0.3 AND (STM/STM_MAX) <= 0.6 AND STM != STM_MAX");

        //    STM 15-30% -> 2 per 5 mins = 24 per hour
        $result_stamina_up = mysql_query("UPDATE " . PHPRPG_DB_PREFIX . "_users SET STM = CEILING(STM + 2 * VIT / 8) * $event_cycles WHERE (STM/STM_MAX) > 0.15 AND (STM/STM_MAX) <= 0.3 AND STM != STM_MAX");

        //    STM  0-15% -> 1 per 5 mins = 12 per hour
        $result_stamina_up = mysql_query("UPDATE " . PHPRPG_DB_PREFIX . "_users SET STM = CEILING(STM + 1 * VIT / 8) * $event_cycles WHERE (STM/STM_MAX) >= 0 AND (STM/STM_MAX) <= 0.15 AND STM != STM_MAX");

        $result_stamina_flat = mysql_query("UPDATE " . PHPRPG_DB_PREFIX . "_users SET STM = STM_MAX WHERE STM > STM_MAX");

        $next_update = time() + (60 * 5);
        $result_update = mysql_query("UPDATE " . PHPRPG_DB_PREFIX . "_events SET requested = '" . time() . "', due = '" . $next_update . "' WHERE task = '" . $event['task'] . "' LIMIT 1");
        $events_string .= ' stamina_recovery';
        break;

    case 'health_recovery':
        // Health recovery every 5 minutes
        // -> amount of recovery depends on VIT

        // Check how many cycles this event might have been missed
        $event_cycles = round((time() - $event['due']) / (60 * 5)) + 1;

        $result_health_up = mysql_query("UPDATE " . PHPRPG_DB_PREFIX . "_users SET HP = ROUND(HP + VIT / 8) * $event_cycles");

        $result_health_flat = mysql_query("UPDATE " . PHPRPG_DB_PREFIX . "_users SET HP = HP_MAX WHERE HP > HP_MAX");

        $next_update = time() + (60 * 5);
        $result_update = mysql_query("UPDATE " . PHPRPG_DB_PREFIX . "_events SET requested = '" . time() . "', due = '" . $next_update . "' WHERE task = '" . $event['task'] . "' LIMIT 1");
        $events_string .= ' health_recovery';
        break;

    case 'optimize_users_pending':
        // Optimize users_pending table every 48 hours
        $result_optimize = mysql_query("OPTIMIZE TABLE " . PHPRPG_DB_PREFIX . "_users_pending");
        $next_update = time() + (60 * 60 * 48);
        $result_update = mysql_query("UPDATE " . PHPRPG_DB_PREFIX . "_events SET requested = '" . time() . "', due = '" . $next_update . "' WHERE task = '" . $event['task'] . "' LIMIT 1");
        $events_string .= ' optimize_users_pending';
        break;

    case 'optimize_sessions':
        // Optimize session table every 24 hours
        $result_optimize = mysql_query("OPTIMIZE TABLE " . PHPRPG_DB_PREFIX . "_sessions");
        $next_update = time() + (60 * 60 * 24);
        $result_update = mysql_query("UPDATE " . PHPRPG_DB_PREFIX . "_events SET requested = '" . time() . "', due = '" . $next_update . "' WHERE task = '" . $event['task'] . "' LIMIT 1");
        $events_string .= ' optimize_sessions';
        break;
}

}

}

/*



            case 'weather':
                while (time() > ($last_update + $update_duration))
                {
                    updateWeather();
                    $last_update += $update_duration;
                    mysql_query("UPDATE " . PHPRPG_DB_PREFIX . "_events SET last_update = " . $last_update . " WHERE event = 'weather'");
                }
                break;
        }
*/
?>