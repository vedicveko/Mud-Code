<?php

error_reporting (E_ALL);

require('config.inc.php');

echo '
<html>
<head>
<title>Create DB tables for phpRPG</title>
</head>
<body>
';


        $db = mysql_pconnect(PHPRPG_DB_HOST, PHPRPG_DB_USER, PHPRPG_DB_PASS) or die(mysql_error());
        mysql_select_db(PHPRPG_DB_NAME) or die(mysql_error());


        echo '* Creating tables.';

/* 9 */

/* EXAMPLE!

        $query = "
INSERT INTO " . PHPRPG_DB_PREFIX . "_users VALUES (10003, 'three', '9a424addb53b0d84304b8e3f5ea44bda', 'cf@thevedic.net', 'Apollo', '', 30, 30, 100, 100, 1000, 1000, 200, 1000, 4, 4, 4, 4, 4, 4, 0, 80, 'Penny Farms', 4, 4, '', '', '', 'Chicken', 'chicken_black', '')
        ";

        $sql = mysql_query($query) or die(mysql_error());
        echo '.';
*/


echo '
</body>
</html>
';

?>
