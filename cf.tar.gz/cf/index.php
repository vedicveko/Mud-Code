<?php
/******************************************************************************/
/*                                                                            */
/* index.php - phpRPG log-in / title page                                     */
/*                                                                            */
/******************************************************************************/

error_reporting (E_ALL);

require('config.inc.php');
include('lib.inc.php');
include('template.inc.php');

DbConnect();
require('lib_events.inc.php');

if (PHPRPG_DEBUG) { $start_time = StartTiming(); }

@$option = $HTTP_GET_VARS['option'];

switch ($option)
{
    case 'activate':
        // Activating an account

        @$user_name = $HTTP_GET_VARS['user_name'];
        @$validate = $HTTP_GET_VARS['validate'];

        include('template_header.inc.php');
        OpenTable('title', '600');
        echo 'Account Activation';
        OpenTable('content');

        if (isset($user_name) && isset($validate))
        {
            $result = mysql_query("SELECT user_name, user_pass, name, email, validate FROM " . PHPRPG_DB_PREFIX . "_users_pending WHERE user_name='$user_name' AND validate='$validate' LIMIT 1");
            if ($result)
            {
                // Is there a matching pair of username and validation string in the pending table?
                if (mysql_num_rows($result) != 0)
                {
                    // Yes -> insert a new row in the main user table

                    // Starting values of all stats

                    list($user_name, $user_pass, $name, $email, $validate) = mysql_fetch_row($result);
                    $result  = mysql_query("
                    INSERT " . PHPRPG_DB_PREFIX . "_users SET
                    user_name='$user_name',
                    user_pass='" . md5($user_pass) . "',
                    email='$email',
                    name='$name',
                    HP=20,
                    HP_MAX=20,
                    MP=10,
                    MP_MAX=10,
                    STM=200,
                    STM_MAX=200,
                    EXP=0,
                    GP=0,
                    STR=4,
                    NTL=4,
                    PIE=4,
                    VIT=4,
                    DEX=4,
                    SPD=4,
                    CW=0,
                    CC=80,
                    map_name='$start_map_name',
                    map_xpos=$start_map_x,
                    map_ypos=$start_map_y,
                    last_active='" . time() . "',
                    race='$start_race',
                    avatar='$start_avatar',
                    host='" . HostIdentify() . "'
                    ") or die('Database Error: ' . mysql_error() . '<br>');

                    $result = mysql_query("SELECT user_id FROM cf_users WHERE user_name='$user_name'");
                    list($bb_id) = mysql_fetch_row($result);

                    // Create BB Account
                    $result  = mysql_query("
                    INSERT bb_users SET
                    user_id = '$bb_id',
                    user_active='1',
                    username='$user_name',
                    user_password='" . md5($user_pass) . "',
                    user_session_time = '0',
                    user_session_page = '0',
                    user_lastvisit = '0',
                    user_regdate = '" . time() . "',
                    user_level = '0',
                    user_posts = '0',
                    user_timezone = '0.00',
                    user_style = '1',
                    user_lang  = 'english',
                    user_dateformat = 'D M d, Y g:i a',
                    user_new_privmsg = '0',
                    user_unread_privmsg = '0',
                    user_last_privmsg = '0',
                    user_viewemail = '0',
                    user_attachsig = '1',
                    user_allowhtml = '0',
                    user_allowbbcode = '1',
                    user_allowsmile = '1',
                    user_allowavatar = '1',
                    user_allow_pm = '1',
                    user_allow_viewonline = '1',
                    user_notify = '0',
                    user_notify_pm = '1',
                    user_popup_pm = '1',
                    user_rank = '0',
                    user_avatar = '0',
                    user_avatar_type = '0',
                    user_email='$email',
                    user_icq = '',
                    user_website = '',
                    user_from = '',
                    user_sig = '',
                    user_sig_bbcode_uid = '',
                    user_aim = '',
                    user_yim = '',
                    user_msnm = '',
                    user_occ = '',
                    user_interests = '',
                    user_actkey = ''
                     ") or die('Database Error: ' . mysql_error() . '<br>');

                    $result  = mysql_query("
                    INSERT bb_user_group SET
                    group_id = '$bb_id',
                    user_id = '$bb_id',
                    user_pending = '0'
                     ") or die('Database Error: ' . mysql_error() . '<br>');
 
                    // Remove from the pending table
                    $result = mysql_query("DELETE FROM " . PHPRPG_DB_PREFIX . "_users_pending WHERE user_name = '$user_name' LIMIT 1");
                    echo 'Congratulations ' . $name . ', your account has been activated!<br><br><a href="index.php">Return to login</a>';
                }
                else
                {
                    // No - return error to user
                    echo 'Validation Error: Your account has either been activated or does not exist in our database!<br>';
                    echo 'Please note that accounts not activated within 48 hours are automatically deleted.';
                }
            }
            else
            {
                echo 'Database Error: ' . mysql_error();
            }
        }
        else
        {
            echo 'Validation Error: The information you are providing is either incorrect or incomplete!';
        }
        OpenTable('close');
        include('template_footer.inc.php');
        break;

    case 'validate':
        // Validate new account registration

        @$user_name = $HTTP_POST_VARS['user_name'];
        @$user_pass1 = $HTTP_POST_VARS['user_pass1'];
        @$user_pass2 = $HTTP_POST_VARS['user_pass2'];
        @$email = $HTTP_POST_VARS['email'];
        @$name = $HTTP_POST_VARS['name'];

        $error_msg = '';

        if (!($user_name && $user_pass1 && $user_pass2 && $email && $name))
        {
            // missing required field
            $error_msg = 'One or more of the required fields are empty.';
        }
        elseif ($user_pass1 != $user_pass2)
        {
            // password mismatch
            $error_msg = 'Passwords do not match.';
        }
        elseif (eregi(' ', $user_pass1))
        {
            // password contained empty space
            $error_msg = 'Passwords cannot contain empty space.';
        }
        elseif (!(eregi('^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*$', $email)))
        {
            // invalid email
            $error_msg = 'Invalid e-mail!<br><font size="1">A valid e-mail address is required to complete the registration.</font>';
            $email = '*Error';
        }
        elseif (!(eregi('^[a-z0-9]*$', $user_name)))
        {
            // invalid username
            $error_msg = 'A username may only contain alpha-numeric characters.';
            $user_name = '*Error';
        }
        elseif (!(eregi('^[a-z]*$', $name)))
        {
            // invalid name
            $error_msg = 'A character name may only compose of alphabets.<br><font size="1">Please Kindly put some thoughts choosing your character name as a sign of respect to the roleplaying community.</font>';
            $name = '*Error';
        }
        else
        {
            // no problems with form, so far...
            $result1 = mysql_query("SELECT user_id FROM " . PHPRPG_DB_PREFIX . "_users WHERE user_name='$user_name' LIMIT 1");
            $result2 = mysql_query("SELECT user_name FROM " . PHPRPG_DB_PREFIX . "_users_pending WHERE user_name='$user_name' LIMIT 1");
            if ((mysql_num_rows($result1) != 0) || (mysql_num_rows($result2) != 0))
            {
                // username exists in either main or pending user database
                $error_msg = 'Sorry, the username ' . $user_name . ' has already been taken!';
                $user_name = "*$user_name";
            }
            $result1 = mysql_query("SELECT user_id FROM " . PHPRPG_DB_PREFIX . "_users WHERE name='$name' LIMIT 1");
            $result2 = mysql_query("SELECT user_name FROM " . PHPRPG_DB_PREFIX . "_users_pending WHERE name='$name' LIMIT 1");
            if ((mysql_num_rows($result1) != 0) || (mysql_num_rows($result2) != 0))
            {
                // character name already exists
                $error_msg = 'Sorry, the character name ' . $name . ' has already been taken!';
                $name = "*$name";
            }
            $result1 = mysql_query("SELECT user_id FROM " . PHPRPG_DB_PREFIX . "_users WHERE email='$email' LIMIT 1");
            $result2 = mysql_query("SELECT user_name FROM " . PHPRPG_DB_PREFIX . "_users_pending WHERE email='$email' LIMIT 1");
            if ((mysql_num_rows($result1) != 0) || (mysql_num_rows($result2) != 0))
            {
                // email already exists
                $error_msg = 'An account has already been registered under this e-mail address!';
                $email = "*$email";
            }
        }

        if ($error_msg == '')
        {
            // Passed validation
            // Generate a random validation string (length of 10 characters)
            $validation_string = '';
            mt_srand((double) microtime() * 100000);
            for ($i = 0; $i < 10; $i++)
            {
                // ASCII for capital letters range from 65 - 90, digits are from 48 - 57
                $rand_val = mt_rand(65, 100);
                if ($rand_val > 90)
                {
                    // if $rand_val > 90, then 91 would generate digit '0'
                    // ... 100 would generate digit '9'
                    $rand_val = $rand_val - 91;
                    $validation_string .= $rand_val;
                } else {
                    // generate upper case letter
                    $validation_string .= chr($rand_val);
                }
            }

            // Insert user details into pending table
            $user_time = time();
            $result = mysql_query("
            INSERT " . PHPRPG_DB_PREFIX . "_users_pending (user_name, user_pass, name, email, validate, rego_time) VALUES
            ('$user_name', '$user_pass1', '$name', '$email', '$validation_string', $user_time)
            ");

            $message  = "Greetings $name,\n\n";
            $message .= "We have recently received your application at " . PHPRPG_BASE . ".\n\n";
            $message .= "To complete the registration, you will have to validate your account through the link below:\n\n";
            $message .= PHPRPG_BASE . "index.php?option=activate&user_name=$user_name&validate=$validation_string\n\n";
            $message .= "Once your account has been activated, you can login with:\n";
            $message .= " > username: $user_name\n";
            $message .= " > password: $user_pass1\n\n";
            $message .= "PLEASE NOTE: Accounts not activated in 48 hours are considered unsuccessful and will automatically be deleted.\n\n";
            $message .= "Thank you for registering with $game_name. I hope you'll enjoy it!!\n\n";
            $message .= "Dean Vaughan\n\n";
            $message .= "http://thevedic.net/cf/\n";

            $subject = '[Aarait] Validation Code';

            $headers  = "From: Aarait Registrar <" . PHPRPG_MAIL . ">\n";
            $headers .= "X-Sender: Aarait Registrar <" . PHPRPG_MAIL . ">\n";
            $headers .= "X-Priority: 1\n";
            $headers .= "Return-Path: Aarait Registrar <" . PHPRPG_MAIL . ">\n";

            // Send validation email! ~ how exciting! :)
            mail($email, $subject, $message, $headers);

            include('template_header.inc.php');
            OpenTable('title', '600');
            echo 'Account Registration';
            OpenTable('content');

            echo '
            <br>Thank you for registering.<br><br>
            You will have to validate your account before you can continue. Please check your e-mail for details.<br><br>
            <b>NOTE:</b> To conserve resources, accounts not activated in 48 hours are considered unsuccessful and will
            automatically be deleted from the server.<br><br>
            <a href="' . PHPRPG_BASE . '">Return to main</a>
            ';
            OpenTable('close');
            include('template_footer.inc.php');
            break;
        }
        else
        {
            // Registration error - pass variables and fall through to case 'register'
            $error_msg = 'Error: ' . $error_msg . '<br><br>';
        }

        // Fall through if account registration fail

    case 'register':
        // New account registration

        include('template_header.inc.php');

        echo '<form action="index.php?option=validate" method="post" autocomplete="off">';

        OpenTable('title', '600');
        echo 'Account Registration';
        OpenTable('content');

        echo '<div align="right"><br>';

        if (@$error_msg) {
            echo $error_msg;
        }

        echo '
        <table cellpadding="5" cellspacing="0" border="0">
            <tr>
                <td><div align="right">Username:<br><font size="1">Your login username is not case sensitive.</font></div></td>
                <td><input type="text" name="user_name" maxlength="20" size="24" value="' . @$user_name . '" class="input"></td>
            </tr>
            <tr>
                <td><div align="right">Password:</div></td>
                <td><input type="password" name="user_pass1" maxlength="20" size="24" class="input"></td>
            </tr>
            <tr>
                <td><div align="right">Confirm Password:</div></td>
                <td><input type="password" name="user_pass2" maxlength="20" size="24" class="input"></td>
            </tr>
            <tr>
                <td><div align="right">Email:<br><font size="1">You must provide a valid e-mail to activate your account.</font></div></td>
                <td><input type="text" name="email" maxlength="60" size="24" value="' . @$email . '" class="input"></td>
            </tr>
            <tr>
                <td><div align="right">Character Name:<br><font size="1">Please choose a sane name.<br>Do not use names which are profane/stupid or the character will be deleted.</font></div></td>
                <td><input type=text name="name" maxlength="20" size="24" value="' . @$name . '" class="input"></td>
            </tr>
        </table>
        <input type="image" name="Register" src="' . PHPRPG_IMG . 'register.png" width="119" height="33" border="0" alt=""></div>
        ';
        OpenTable('close');
        echo '</form>';

        include('template_footer.inc.php');

        break;

    case 'login':
        // Login verification

        @$user_name = $HTTP_POST_VARS['user_name'];
        @$user_pass = md5($HTTP_POST_VARS['user_pass']);

        if (!empty($user['user_id']))
        {
            unset($user['user_id']);
        }
        $result = mysql_query("SELECT user_id, name FROM " . PHPRPG_DB_PREFIX . "_users WHERE user_name='$user_name' AND user_pass='$user_pass' LIMIT 1");
        $user = mysql_fetch_array($result);
        if ($user['user_id'])
        {
            // User exists! -> Starts session

            // Set session handler
            session_set_save_handler('SessOpen', '', 'SessRead', 'SessWrite', 'SessDestroy', 'SessGc');

            // Generate new random session id
            mt_srand((double)microtime()*100000);
            $s = md5(uniqid(mt_rand()));

            // Register session id and start session
            session_id($s);
            session_start();
            session_register('user_id', 'user_time');

            $user_id = $user['user_id'];
            $user_time = time();
            $user_host = HostIdentify();
            $result = mysql_query("UPDATE " . PHPRPG_DB_PREFIX . "_users SET last_active='$user_time', host='$user_host' WHERE user_id='$user_id' LIMIT 1");

            include('template_header.inc.php');

            OpenTable('title', '600');
            echo "Welcome to $game_name!";
            OpenTable('content');

            echo 'Greetings, ' . $user['name'] . '...<br>';

            // Display admin notes to players
            include('notes.php');

            echo '<br><div align="right"><a href="local.php?s=' . $s . '"><img src="' . PHPRPG_IMG . 'start.png" width="81" height="30" border="0" alt=""></a></div>';
            OpenTable('close');

            include('template_footer.inc.php');

            break;
        } else {
            // Incorrect login or database error -> fallthrough
            $login_error = True;
        }

    default:
        // Default page

        include('template_header.inc.php');

/*        // Log visitor's information
        if (empty($HTTP_USER_AGENT))
        {
            $HTTP_USER_AGENT = getenv('HTTP_USER_AGENT');
        }
        if (empty($HTTP_REFERER))
        {
            $HTTP_REFERER = getenv('HTTP_REFERER');
        }
        $result = mysql_query("INSERT DELAYED " . PHPRPG_DB_PREFIX . "_activity (day, hour, agent, host, ref) VALUES ('" . date('Y-m-d', mktime()) . "', " . date('H', mktime()) . ", '" . $HTTP_USER_AGENT . "', '" . HostIdentify() . "', '" . $HTTP_REFERER . "')") or die('Database Error: ' . mysql_error() . '<br>');
*/
        echo '
<img src="' . PHPRPG_IMG . 'x.png" width="0" height="10" border="0" alt=""><br>
<table cellpadding="0" cellspacing="0" border="0" width="100%">
<tr>
<td width="100%"><img src="' . PHPRPG_IMG . 'x.png" width="0" height="122" border="0" alt=""><br></td>
<td width="547"><img src="' . PHPRPG_IMG . 'aarait_logo_top.png" width="547" height="122" border="0" alt=""></td>
</tr>
<tr>
<td bgcolor="#000000" align="left" valign="bottom">

<form action="index.php?option=login" method="post" name="login_form" autocomplete="off">
<table cellpadding="3" cellspacing="0" border="0">
        ';

        if (@$login_error) { echo '<tr><td></td><td colspan="2"><font size="2"><i>Login error!</i></font></td></tr>'; }

        echo '
<tr>
<td><img src="' . PHPRPG_IMG . 'x.png" width="0" height="0" hspace="10" border="0" alt=""></td>
<td><font size="2">Username</font></td>
<td><input type="text" name="user_name" size="20" maxlength="22" class="input"></td>
</tr>
<tr>
<td></td>
<td><font size="2">Password</font></td>
<td><input type="password" name="user_pass" size="20" maxlength="22" class="input"></td>
</tr>
<tr><td></td><td colspan="2"><div align="right">
<a href="index.php?option=register"><font size="2">[register]</font></a>
<input type="submit" value="Login" class="inputbutton"><br>
<P><h2><font color=red> VERSION: ALPHA</font></h2><P>
</div>
</td></tr>
</table>
</form>

<script language="Javascript">
<!--
    document.onLoad = document.login_form.user_name.focus();
// -->
</script>

</td>
<td><img src="' . PHPRPG_IMG . 'aarait_logo_bot.png" width="547" height="268" border="0" alt=""></td>
</tr>
</table>
<br>
<img src="' . PHPRPG_IMG . 'x.png" width="0" height="15" border="0" alt=""><br>
        ';

        echo '
<div align="center"><font color=white>';

include('/home/vedic/www/BOTTOM-INCLUDE.TXT');

echo '
</div>
        ';
    include('template_footer.inc.php');
}


?>
