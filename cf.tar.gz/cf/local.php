<?php
/******************************************************************************/
/*                                                                            */
/* local.php - Local View                                                     */
/*                                                                            */
/******************************************************************************/

error_reporting (E_ALL);

require('config.inc.php');
include('lib.inc.php');
include('template.inc.php');

require('lib_session.inc.php');

require('lib_events.inc.php');

// Process and send chat messages to db if $option = 'chat'
if (@$option == 'chat')
{
    include('lib_chat.inc.php');
}

require('template_header.inc.php');

echo '
<table cellpadding="0" cellspacing="10" width="100%" border="0">
<tr><td width="100%" valign="top">
';

OpenTable('title', '100%');
echo "$game_name";
OpenTable('content');

$map = $char['map_name'];
$x = $char['map_xpos'];
$y = $char['map_ypos'];

$result = mysql_query("SELECT room_name, room_desc FROM " . PHPRPG_DB_PREFIX . "_map WHERE name='$map' AND xpos='$x' AND ypos='$y'");
$room_info = mysql_fetch_array($result);
mysql_free_result($result);

echo '
<div align="justify">
Local View :: ' . $char['map_name'] . ' :: ' . $room_info['room_name'] . ' (' . $x . ', ' . $y . ')<p>
' . $room_info['room_desc'] . '<p>
';

menu($char['name'], $char['user_pass'], $s, $char['admin_level']);

if (!empty($reason))
{
    include('template_reason.inc.php');
}

echo '
</font>

<table cellpadding="0" cellspacing="15" border="0">
<tr><td valign="top">
';

// Navigation window
include('template_nav.inc.php');

echo '
</td><td valign="top">
';

// Chat box
include('template_chat.inc.php');

echo '
<div align="right">
';

// Items on the ground
include('template_dropped.inc.php');

echo '
</div>
';

echo '
</td></tr></table>

</div>';

OpenTable('close');

echo '
</td><td width="172" valign="top">
';

// Stats Box
include('template_stats.inc.php');

echo '
</td></tr></table>
';

require('template_footer.inc.php');
?>
