<?php


// phpBB 2.x auto-generated config file
// Do not change anything in this file!

$dbms = 'mysql';

$dbhost = 'localhost';
$dbname = 'vedic';
$dbuser = 'vedic';
$dbpasswd = 'r3drum';

$table_prefix = 'bb_';

define('PHPBB_INSTALLED', true);

?>