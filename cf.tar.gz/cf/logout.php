<?php
/******************************************************************************/
/*                                                                            */
/* logout.php - Terminate current session and log out                         */
/*                                                                            */
/******************************************************************************/

error_reporting (E_ALL);

require('config.inc.php');
include('lib.inc.php');
include('template.inc.php');

DbConnect();

require('lib_events.inc.php');

session_set_save_handler('SessOpen', '', 'SessRead', 'SessWrite', 'SessDestroy', 'SessGc');
session_id($s);
session_start();

if (empty($HTTP_SESSION_VARS['user_id']))
{
    header("Location: index.php");
}
else
{
// Set last_active = '0' to indicate logged out
$result = mysql_query("UPDATE " . PHPRPG_DB_PREFIX . "_users SET last_active='0' WHERE user_id=$user_id LIMIT 1");

// Destroys current session and variables
session_unset();
session_destroy();

require('template_header.inc.php');
OpenTable('title', '500');
echo "$game_name";
OpenTable('content');

echo '
<div align="justify">
You have successfully logged out...<br>
<br>
<a href="index.php">Return to login</a>
</div>
';

OpenTable('close');

require('template_footer.inc.php');
}
?>
