<?php
/******************************************************************************/
/*                                                                            */
/* template_header.inc.php - HTML Header                                      */
/*                                                                            */
/******************************************************************************/

error_reporting (E_ALL);

if (eregi('.inc.php', $HTTP_SERVER_VARS['PHP_SELF']))
{
    header('Location: index.php');
}
else
{

// Get game time-dependent background colours

$html_background_80 = BackgroundColour(80);
$html_background_75 = BackgroundColour(75);
$html_background_70 = BackgroundColour(70);
$html_background_65 = BackgroundColour(65);
$html_background_60 = BackgroundColour(60);
$html_background_55 = BackgroundColour(55);
$html_background_50 = BackgroundColour(50);
$html_background_45 = BackgroundColour(45);
$html_background_40 = BackgroundColour(40);

// Ensures content is dynamic, uncached
header("Expires: Mon, 6 Dec 1977 00:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . "GMT");
header("Cache-Control: no-cache, must-revalidate");
header("Pragma: no-cache");

echo '
<html>
<head>
<title>Aarait 2: Chicken Fight :: a thevedic.net Production</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta name="Description" content="Aarait 2 is an web browser based multiplayer fishing roleplaying game. Enter and experience the realm of Aarait!">
<meta name="Author" content="Dean Vaughan">
<meta name="Keywords" content="AARAIT, CHICKEN, FIGHT, RABID, FISHIES, MUD, RPG, ROLE, PLAYING, GAME, MULTI, PLAYER, ONLINE, WEB, BROWSER, FREE, MULTIPLAYER, SPELL, CASTING, FIGHTER, MAGE, WIZARD, BARD, PSIONIC, ALCHEMIST, PRIEST, SAGE, VAMPIRE, UNDEAD, SPIRIT, SOUL">

<style type="text/css">
<!--
body
{
    font: 12px arial, helvetica; color: #bbbbbb; background: ' . $html_background_40 . '; text-align: justify; margin: 0px;
    scrollbar-face-color : #212121;
    scrollbar-shadow-color : #c1c1c1;
    scrollbar-highlight-color : #c1c1c1;
    scrollbar-3dlight-color : #212121;
    scrollbar-darkshadow-color : #212121;
    scrollbar-track-color: #212121;
    scrollbar-arrow-color : #c1c1c1;
}
table
{
    font: 12px arial, helvetica; color: #bbbbbb; text-align: justify; margin: 0px;
}
a:link, A:visited, A:active { color: #6181b1; text-decoration: none; }
a:hover { color: #b1d1f1; text-decoration: none; }
.input
{
    font: 14px bold; color: #c1c1c1; background: #212121;
    border: 1px #a1a1a1 solid;
    margin-top: 1px; margin-bottom: 1px;
    width: 100px; height: 20px;
    clip: rect();
}
.inputbutton
{
    font: 9px bold; color: #d1d1d1; background: #212121;
    border: 1px #d1d1d1 solid;
    margin-top: 1px; margin-bottom: 1px;
    height: 20px;
    clip: rect();
}
// -->
</style>
<base href="' . PHPRPG_BASE . '">
<link rel="SHORTCUT ICON" href="' . PHPRPG_BASE . 'favicon.ico">
</head>

<body bgcolor="' . $html_background_40 . '" text="#bbbbbb" link="#6181b1" vlink="#6181b1" alink="#6181b1">

<table cellpadding="0" cellspacing="0" border="0" width="100%">
<tr><td bgcolor="' . $html_background_80 . '" width="100%"><img src="' . PHPRPG_IMG . 'x.png" width="0" height="7" border="0" alt=""></td></tr>
<tr><td bgcolor="' . $html_background_75 . '" width="100%"><img src="' . PHPRPG_IMG . 'x.png" width="0" height="7" border="0" alt=""></td></tr>
<tr><td bgcolor="' . $html_background_70 . '" width="100%"><img src="' . PHPRPG_IMG . 'x.png" width="0" height="7" border="0" alt=""></td></tr>
<tr><td bgcolor="' . $html_background_65 . '" width="100%"><img src="' . PHPRPG_IMG . 'x.png" width="0" height="7" border="0" alt=""></td></tr>
<tr><td bgcolor="' . $html_background_60 . '" width="100%"><img src="' . PHPRPG_IMG . 'x.png" width="0" height="7" border="0" alt=""></td></tr>
<tr><td bgcolor="' . $html_background_55 . '" width="100%"><img src="' . PHPRPG_IMG . 'x.png" width="0" height="7" border="0" alt=""></td></tr>
<tr><td bgcolor="' . $html_background_50 . '" width="100%"><img src="' . PHPRPG_IMG . 'x.png" width="0" height="7" border="0" alt=""></td></tr>
<tr><td bgcolor="' . $html_background_45 . '" width="100%"><img src="' . PHPRPG_IMG . 'x.png" width="0" height="7" border="0" alt=""></td></tr>
<tr><td bgcolor="' . $html_background_40 . '" width="100%"><img src="' . PHPRPG_IMG . 'x.png" width="0" height="7" border="0" alt=""></td></tr>
<tr><td bgcolor="' . $html_background_40 . '" width="100%">
<div align="center">
';

if (PHPRPG_DEBUG)
{
    $start_time = StartTiming();
}

}
?>
