<?php

echo '
<br>
<font style="font-size: 18px; font-family: Arial;">Instructions</font><br>
A [Local View] is the area bounded by a single tile. If there are other players or items in the area, they will be shown.
Your unique position on the map is indicated below the navigation box. You can navigate between areas by clicking on adjacent tiles or using
your keyboard if JavaScript is enabled:<br>
- [1] -> move down-left<br>
- [2] -> move down<br>
- [3] -> move down-right<br>
- [4] -> move up-left<br>
- [5] -> move up<br>
- [6] -> move up-right<br>
- [enter] -> enter chat mode (focus chat box)<br>
- [ESC] -> exit chat mode<br>
<br>
To the right of the user interface is the game time and player statistics. The timing in Aarait is four times faster than real time.
Each cycle of the day is indicated by the order of red, yellow, green and blue.<br>
<br>
Moving around the map consumes stamina and every move of the player may or may not incur a real-time delay.<br>
<br>
If there are items on the ground, you can simply pick it up by clicking on it. To use a weapon, you will have to equip it in the [Player Status] menu.
Sometimes an item which is rare requires greater experience to recognise. You can click on [identify] to try your luck and chance.<br>
<br>
[Battle Mode] allows combat to be engaged. Each attack is initiated by clicking on the [Attack] icon. On every attack, the target would counterattack.
Once the health of a player has reached zero, he or she will fall unconscious and be transferred to a specific location. Any item on the defeated
player will be dropped onto the ground.<br>
<br>
[Online Players] tells you who is actually logged on. At the bottom are top 10 players who have achieved the most experience.<br>
<br>
To start off with, move around the map and pick up some "auras" if you can find one. Equip the auras and start beating people up! :)<br>
<br>
Target One, Target Two and Target Three would be your ideal first targets.<br>
<br>
A more refined documentation will be on its way once the game is more complete! Enjoy!<br>
<br>
<br>
';
?>
